"""CNN architecture for video deepfake classification (face-crop input).
Uses a pretrained ResNet18 backbone, fine-tuned for binary classification.
"""
import torch.nn as nn
import torchvision.models as models


class VideoCNN(nn.Module):
    def __init__(self, pretrained: bool = True):
        super().__init__()
        backbone = models.resnet18(weights="IMAGENET1K_V1" if pretrained else None)
        # Replace final layer for binary classification
        backbone.fc = nn.Linear(backbone.fc.in_features, 1)
        self.backbone = backbone

    def forward(self, x):
        return self.backbone(x)
