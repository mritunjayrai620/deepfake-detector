"""
Video Deepfake Detection Service
Extracts face frames from an uploaded video and classifies them as real or manipulated.
"""
import io
import tempfile
import numpy as np
import cv2
import torch
from fastapi import FastAPI, UploadFile, File

from model import VideoCNN

app = FastAPI(title="Video Detection Service")

MODEL_PATH = "model_weights/video_cnn.pt"
FRAME_SAMPLE_RATE = 5  # analyze every Nth frame
IMG_SIZE = 224

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = VideoCNN().to(device)

try:
    model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
    model.eval()
    MODEL_LOADED = True
except FileNotFoundError:
    MODEL_LOADED = False

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")


def extract_face_frames(video_path: str) -> list[np.ndarray]:
    cap = cv2.VideoCapture(video_path)
    frames = []
    idx = 0
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        if idx % FRAME_SAMPLE_RATE == 0:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.1, 4)
            for (x, y, w, h) in faces:
                face = frame[y:y + h, x:x + w]
                face = cv2.resize(face, (IMG_SIZE, IMG_SIZE))
                frames.append(face)
        idx += 1
    cap.release()
    return frames


def frames_to_tensor(frames: list[np.ndarray]) -> torch.Tensor:
    batch = np.stack(frames).astype(np.float32) / 255.0
    batch = np.transpose(batch, (0, 3, 1, 2))  # NHWC -> NCHW
    return torch.tensor(batch, dtype=torch.float32).to(device)


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": MODEL_LOADED}


@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    contents = await file.read()

    if not MODEL_LOADED:
        return {"label": "unknown", "confidence": 0.0, "note": "model not loaded"}

    with tempfile.NamedTemporaryFile(suffix=".mp4", delete=True) as tmp:
        tmp.write(contents)
        tmp.flush()
        frames = extract_face_frames(tmp.name)

    if not frames:
        return {"label": "no_face_detected", "confidence": 0.0}

    tensor = frames_to_tensor(frames)
    with torch.no_grad():
        scores = torch.sigmoid(model(tensor)).cpu().numpy().flatten()

    avg_score = float(np.mean(scores))
    label = "synthetic" if avg_score > 0.5 else "real"
    return {
        "label": label,
        "confidence": round(avg_score, 4),
        "frames_analyzed": len(frames),
    }
