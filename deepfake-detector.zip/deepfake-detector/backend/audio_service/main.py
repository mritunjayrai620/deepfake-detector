"""
Audio Deepfake Detection Service
Loads a trained CNN and classifies uploaded audio as real or synthetic speech.
"""
import io
import numpy as np
import librosa
import torch
from fastapi import FastAPI, UploadFile, File

from model import AudioCNN

app = FastAPI(title="Audio Detection Service")

MODEL_PATH = "model_weights/audio_cnn.pt"
SAMPLE_RATE = 16000
N_MELS = 128

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = AudioCNN().to(device)

try:
    model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
    model.eval()
    MODEL_LOADED = True
except FileNotFoundError:
    # Model not trained yet — service still starts so the rest of the
    # stack can be developed/tested against a stub response.
    MODEL_LOADED = False


def audio_to_spectrogram(audio_bytes: bytes) -> torch.Tensor:
    y, sr = librosa.load(io.BytesIO(audio_bytes), sr=SAMPLE_RATE)
    mel = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=N_MELS)
    mel_db = librosa.power_to_db(mel, ref=np.max)
    # normalize to [0, 1]
    mel_norm = (mel_db - mel_db.min()) / (mel_db.max() - mel_db.min() + 1e-9)
    tensor = torch.tensor(mel_norm, dtype=torch.float32).unsqueeze(0).unsqueeze(0)
    return tensor.to(device)


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": MODEL_LOADED}


@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    contents = await file.read()

    if not MODEL_LOADED:
        # Stub response so the gateway/frontend can be built/tested
        # before the model finishes training.
        return {"label": "unknown", "confidence": 0.0, "note": "model not loaded"}

    spectrogram = audio_to_spectrogram(contents)
    with torch.no_grad():
        score = torch.sigmoid(model(spectrogram)).item()

    label = "synthetic" if score > 0.5 else "real"
    return {"label": label, "confidence": round(score, 4)}
