"""
FastAPI Gateway
Responsibilities: auth, request routing, rate limiting, response aggregation, logging.
"""
import time
import httpx
from fastapi import FastAPI, UploadFile, File, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from jose import jwt, JWTError

app = FastAPI(title="Deepfake Detector Gateway")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this in production
    allow_methods=["*"],
    allow_headers=["*"],
)

SECRET_KEY = "change-this-in-production"
ALGORITHM = "HS256"

AUDIO_SERVICE_URL = "http://audio_service:8001"
VIDEO_SERVICE_URL = "http://video_service:8002"

# --- simple in-memory rate limiter (swap for slowapi/redis in production) ---
request_log: dict[str, list[float]] = {}
RATE_LIMIT = 10  # requests
RATE_WINDOW = 60  # seconds


def check_rate_limit(client_id: str):
    now = time.time()
    timestamps = [t for t in request_log.get(client_id, []) if now - t < RATE_WINDOW]
    if len(timestamps) >= RATE_LIMIT:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    timestamps.append(now)
    request_log[client_id] = timestamps


def verify_token(request: Request) -> str:
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid token")
    token = auth_header.split(" ")[1]
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload.get("sub", "anonymous")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/analyze/audio")
async def analyze_audio(file: UploadFile = File(...), user: str = Depends(verify_token)):
    check_rate_limit(user)
    start = time.time()

    contents = await file.read()
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            f"{AUDIO_SERVICE_URL}/predict",
            files={"file": (file.filename, contents, file.content_type)},
        )
    response.raise_for_status()
    result = response.json()

    latency_ms = round((time.time() - start) * 1000, 2)
    # TODO: write {user, "audio", result, latency_ms} to Postgres
    result["latency_ms"] = latency_ms
    return result


@app.post("/analyze/video")
async def analyze_video(file: UploadFile = File(...), user: str = Depends(verify_token)):
    check_rate_limit(user)
    start = time.time()

    contents = await file.read()
    async with httpx.AsyncClient(timeout=60.0) as client:
        response = await client.post(
            f"{VIDEO_SERVICE_URL}/predict",
            files={"file": (file.filename, contents, file.content_type)},
        )
    response.raise_for_status()
    result = response.json()

    latency_ms = round((time.time() - start) * 1000, 2)
    # TODO: write {user, "video", result, latency_ms} to Postgres
    result["latency_ms"] = latency_ms
    return result
