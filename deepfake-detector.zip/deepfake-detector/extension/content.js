// Injects a small overlay badge showing the live detection status.

const badge = document.createElement("div");
badge.id = "deepfake-detector-badge";
badge.style.cssText = `
  position: fixed; top: 16px; right: 16px; z-index: 999999;
  padding: 6px 12px; border-radius: 999px; font: 500 12px sans-serif;
  background: #888; color: white; transition: background 0.3s;
`;
badge.textContent = "Deepfake check: idle";
document.body.appendChild(badge);

chrome.runtime.onMessage.addListener((message) => {
  if (message.type !== "DETECTION_RESULT") return;
  const { label, confidence } = message.result;

  if (label === "synthetic") {
    badge.style.background = "#D85A30"; // coral/red — flagged
    badge.textContent = `Possible synthetic voice (${Math.round(confidence * 100)}%)`;
  } else if (label === "real") {
    badge.style.background = "#1D9E75"; // teal/green — clear
    badge.textContent = `Voice looks natural (${Math.round((1 - confidence) * 100)}%)`;
  } else {
    badge.style.background = "#888";
    badge.textContent = "Deepfake check: analyzing...";
  }
});
