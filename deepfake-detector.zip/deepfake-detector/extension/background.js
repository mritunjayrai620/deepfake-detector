// Background service worker: manages tab audio capture and relays
// chunks to the backend audio service for scoring.

const GATEWAY_URL = "http://localhost:8000/analyze/audio";
const CHUNK_DURATION_MS = 3000;

let capturing = false;

chrome.action.onClicked.addListener((tab) => {
  if (capturing) {
    stopCapture();
  } else {
    startCapture(tab.id);
  }
});

function startCapture(tabId) {
  chrome.tabCapture.capture({ audio: true, video: false }, (stream) => {
    if (!stream) {
      console.error("tabCapture failed:", chrome.runtime.lastError);
      return;
    }
    capturing = true;
    recordAndSendChunks(stream, tabId);
  });
}

function stopCapture() {
  capturing = false;
}

async function recordAndSendChunks(stream, tabId) {
  const recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
  let chunks = [];

  recorder.ondataavailable = (e) => chunks.push(e.data);

  recorder.onstop = async () => {
    const blob = new Blob(chunks, { type: "audio/webm" });
    chunks = [];

    const formData = new FormData();
    formData.append("file", blob, "chunk.webm");

    try {
      const res = await fetch(GATEWAY_URL, {
        method: "POST",
        headers: { Authorization: "Bearer <token>" }, // TODO: real auth
        body: formData,
      });
      const result = await res.json();
      chrome.tabs.sendMessage(tabId, { type: "DETECTION_RESULT", result });
    } catch (err) {
      console.error("Failed to analyze audio chunk:", err);
    }

    if (capturing) {
      recorder.start();
      setTimeout(() => recorder.stop(), CHUNK_DURATION_MS);
    }
  };

  recorder.start();
  setTimeout(() => recorder.stop(), CHUNK_DURATION_MS);
}
