# AI Deepfake & Voice-Clone Detector — Execution Roadmap

A 12-week, phase-by-phase build plan. Each phase lists concrete tasks, tools/commands, and the deliverable you should have by the end of it.

---

## Phase 1: Setup & Data (Weeks 1–2)

**Goal:** Working dev environment + clean, labeled datasets ready for training.

1. **Set up your repo structure**
   ```
   deepfake-detector/
     backend/
       gateway/          # FastAPI gateway
       audio_service/
       video_service/
     frontend/            # React/Next.js dashboard
     extension/           # Chrome extension
     ml/
       audio/notebooks
       video/notebooks
     docker-compose.yml
   ```
   Initialize git, push to GitHub early — commit history matters for your evaluation.

2. **Download and explore datasets**
   - Audio: [ASVspoof 2019/2021](https://www.asvspoof.org/) (LA — logical access — subset is enough)
   - Video: [FaceForensics++](https://github.com/ondyari/FaceForensics) (request access via their form; use the c23 compressed version to keep file sizes manageable)
   - Run a quick exploratory notebook: check class balance, sample durations/resolutions, listen to/watch a few samples

3. **Preprocessing pipeline (audio)**
   - Use `librosa` to convert `.wav` files to mel-spectrograms (128 mel bands, 25ms window, 10ms hop)
   - Save as `.npy` arrays or cache spectrogram images to speed up training later

4. **Preprocessing pipeline (video)**
   - Use `OpenCV` or `dlib`/`MTCNN` to extract face crops from video frames (sample every 5th frame to save compute)
   - Resize to a consistent input size (e.g. 224x224)

**Deliverable:** Two clean, preprocessed datasets (audio spectrograms + video face crops) with train/val/test splits, plus a working repo skeleton.

---

## Phase 2: Audio Classifier (Weeks 3–5)

**Goal:** A trained, evaluated CNN that classifies real vs. synthetic speech.

1. **Build the model** (PyTorch or TensorFlow/Keras — pick one and stay consistent across both models)
   - 3 conv blocks (Conv2D → BatchNorm → ReLU → MaxPool), increasing filters (32→64→128)
   - Global average pooling → Dense(64) → Dropout(0.3) → Dense(1, sigmoid)

2. **Train**
   - Binary cross-entropy loss, Adam optimizer (lr=1e-3, reduce on plateau)
   - Use a GPU — Google Colab (free tier) or Kaggle Notebooks (free 30hrs/week GPU) are enough for this scale
   - Log metrics with `wandb` or simple matplotlib plots (loss/accuracy curves) — screenshot these for your report

3. **Augment for robustness**
   - Add background noise, pitch shift, time-stretch (use `audiomentations` library)
   - This matters a lot once you test with real Zoom/Meet-compressed audio later

4. **Evaluate**
   - Report accuracy, precision/recall, F1, and EER (Equal Error Rate — the standard metric in deepfake-audio literature, worth citing)
   - Save the trained model weights (`.pt` or `.h5`)

**Deliverable:** A trained audio model file + an evaluation notebook with metrics and confusion matrix, ready to wrap in an API.

---

## Phase 3: Video Classifier (Weeks 6–8)

**Goal:** A trained CNN that flags manipulated faces frame-by-frame.

1. **Build the model**
   - Start with a pretrained backbone (XceptionNet or ResNet50 via `torchvision`/`keras.applications`) and fine-tune — training from scratch on FaceForensics++ alone is slow and less accurate
   - Freeze early layers initially, unfreeze gradually (progressive fine-tuning) if time allows

2. **Train**
   - Same infra as audio (Colab/Kaggle GPU)
   - This will take longer per epoch than audio — start this phase early, don't compress it

3. **Add interpretability (stretch but high-value)**
   - Implement Grad-CAM to visualize which facial regions triggered a "fake" classification
   - This is one of the most demo-impressive parts of the project — prioritize it if you're ahead of schedule

4. **Evaluate**
   - Accuracy, precision/recall, F1 on held-out FaceForensics++ test split
   - Test on a few videos from a *different* deepfake source (e.g. Celeb-DF) to honestly report generalization limits — mention this in your report as a known limitation

**Deliverable:** A trained video model + Grad-CAM visualization code + evaluation metrics.

---

## Phase 4: Full-Stack Integration (Weeks 9–10)

**Goal:** Working end-to-end app — upload a file, get a verdict.

1. **Wrap each model in its own FastAPI service**
   - `POST /predict` endpoint per service, accepts file, returns `{score, label, confidence}`
   - Load model once at startup (not per-request) for latency

2. **Build the gateway**
   - Routes requests to the right service based on file type
   - Handles auth (simple JWT is enough), rate limiting (`slowapi` library), and response aggregation for combined audio+video files
   - Logs every request to PostgreSQL (timestamp, user, service, latency, score)

3. **Build the frontend**
   - Upload UI (drag-and-drop), results page (score, confidence, spectrogram/Grad-CAM visualization)
   - History dashboard pulling from your Postgres logs

4. **Containerize**
   - `Dockerfile` per service, `docker-compose.yml` to run everything together locally
   - This also makes deployment much easier in the next phase

**Deliverable:** A working local full-stack app — upload → analysis → result, backed by both real trained models.

---

## Phase 5: Live Extension (Week 11)

**Goal:** Chrome extension that streams call audio to your backend for near-real-time detection.

1. **Scaffold the extension** (Manifest V3)
   - `manifest.json` with `tabCapture`, `activeTab`, host permissions for `meet.google.com`/`zoom.us`
   - Background service worker to manage capture sessions

2. **Capture and chunk audio**
   - `chrome.tabCapture.capture()` → `MediaStream` → `AudioContext` + `AudioWorkletNode` to grab 3-second chunks

3. **Send to backend**
   - POST each chunk to your audio service endpoint (reuse the same model — no separate training needed)
   - Show a small overlay badge (green/amber/red) via a content script

4. **Test realistically**
   - Play a known synthetic-voice sample into a test call and confirm detection
   - Document the actual latency you observe — be honest about it in your report

**Deliverable:** A working extension demo (even if scoped down — e.g. manual "analyze last 3 seconds" button is a fine fallback if full streaming proves too fragile in the time left).

---

## Phase 6: Deploy, Polish, Document (Week 12)

**Goal:** Live, demoable, well-documented project.

1. **Deploy**
   - Backend services + gateway → Render or Railway (Docker-friendly, generous free tiers)
   - Frontend → Vercel
   - Database → managed Postgres (Render/Railway both offer this)

2. **Polish**
   - Error states, loading indicators, a clean landing page explaining the project
   - Fix any obvious bugs from your own end-to-end testing

3. **Write the report**
   - Architecture diagram, dataset description, model architecture + metrics, limitations section (be upfront about generalization gaps — examiners respect this), and a short ethics note on privacy/consent for the live-call feature

4. **Prepare the demo**
   - Pre-select 2–3 clear real/fake examples that work reliably — don't rely on live internet during your viva
   - Have a backup video recording of the demo in case of live-demo failure

**Deliverable:** Live deployed app, GitHub repo with README, final report, and a rehearsed demo.

---

## Time-saving notes

- **Start the video model early** — it's the slowest-training piece; don't leave it until week 8 if you can shift it earlier.
- **Use pretrained backbones** for video — training from scratch wastes weeks for marginal gains at this scale.
- **Google Colab/Kaggle free GPU tiers are sufficient** for both models at the dataset sizes described here — no need to pay for cloud GPU unless you want to scale up later.
- **If time runs short**, cut the live extension to a simplified "record 5 seconds, click analyze" version rather than full continuous streaming — it still demonstrates the concept without the Manifest V3 complexity risk.
