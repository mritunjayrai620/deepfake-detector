"""
Training script for the audio deepfake classifier.

Dataset: ASVspoof 2019 LA (https://www.asvspoof.org/index2019.html)
Expected layout after download:
    data/
      ASVspoof2019_LA_train/flac/*.flac
      ASVspoof2019_LA_train/protocol.txt   # bonafide / spoof labels
"""
import sys
import os
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import librosa
import numpy as np

sys.path.append(os.path.join(os.path.dirname(__file__), "../../backend/audio_service"))
from model import AudioCNN  # noqa: E402

SAMPLE_RATE = 16000
N_MELS = 128
BATCH_SIZE = 32
EPOCHS = 20
LR = 1e-3


class ASVspoofDataset(Dataset):
    """Expects a list of (filepath, label) tuples, label: 0=real (bonafide), 1=fake (spoof)."""

    def __init__(self, file_label_pairs):
        self.data = file_label_pairs

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        filepath, label = self.data[idx]
        y, sr = librosa.load(filepath, sr=SAMPLE_RATE)
        mel = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=N_MELS)
        mel_db = librosa.power_to_db(mel, ref=np.max)
        mel_norm = (mel_db - mel_db.min()) / (mel_db.max() - mel_db.min() + 1e-9)
        # pad/truncate to a fixed width so batches stack cleanly
        target_width = 128
        if mel_norm.shape[1] < target_width:
            pad = target_width - mel_norm.shape[1]
            mel_norm = np.pad(mel_norm, ((0, 0), (0, pad)))
        else:
            mel_norm = mel_norm[:, :target_width]
        tensor = torch.tensor(mel_norm, dtype=torch.float32).unsqueeze(0)
        return tensor, torch.tensor([label], dtype=torch.float32)


def load_protocol(protocol_path: str, audio_dir: str):
    """Parse the ASVspoof protocol file into (filepath, label) pairs.
    Adjust parsing to match the exact protocol format you download.
    """
    pairs = []
    with open(protocol_path) as f:
        for line in f:
            parts = line.strip().split()
            filename, tag = parts[1], parts[-1]  # adjust indices to actual protocol format
            label = 0 if tag == "bonafide" else 1
            pairs.append((os.path.join(audio_dir, f"{filename}.flac"), label))
    return pairs


def train():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Training on {device}")

    train_pairs = load_protocol("data/protocol_train.txt", "data/ASVspoof2019_LA_train/flac")
    val_pairs = load_protocol("data/protocol_dev.txt", "data/ASVspoof2019_LA_dev/flac")

    train_loader = DataLoader(ASVspoofDataset(train_pairs), batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(ASVspoofDataset(val_pairs), batch_size=BATCH_SIZE)

    model = AudioCNN().to(device)
    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=2)

    best_val_loss = float("inf")
    for epoch in range(EPOCHS):
        model.train()
        train_loss = 0.0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            out = model(x)
            loss = criterion(out, y)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        model.eval()
        val_loss = 0.0
        correct = 0
        total = 0
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(device), y.to(device)
                out = model(x)
                val_loss += criterion(out, y).item()
                preds = (torch.sigmoid(out) > 0.5).float()
                correct += (preds == y).sum().item()
                total += y.size(0)

        avg_train_loss = train_loss / len(train_loader)
        avg_val_loss = val_loss / len(val_loader)
        val_acc = correct / total
        scheduler.step(avg_val_loss)

        print(f"Epoch {epoch+1}/{EPOCHS} | train_loss={avg_train_loss:.4f} "
              f"val_loss={avg_val_loss:.4f} val_acc={val_acc:.4f}")

        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            os.makedirs("../../backend/audio_service/model_weights", exist_ok=True)
            torch.save(model.state_dict(), "../../backend/audio_service/model_weights/audio_cnn.pt")
            print("  -> saved new best model")


if __name__ == "__main__":
    train()
