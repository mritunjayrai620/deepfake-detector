"""
Training script for the video (facial) deepfake classifier.

Dataset: FaceForensics++ (https://github.com/ondyari/FaceForensics)
Use the c23 compressed version to keep storage manageable.
Expected layout: face crops already extracted to
    data/faces/real/*.jpg
    data/faces/fake/*.jpg
(use a preprocessing script with OpenCV/MTCNN to extract face crops from
raw videos before running this training script)
"""
import sys
import os
import glob
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image

sys.path.append(os.path.join(os.path.dirname(__file__), "../../backend/video_service"))
from model import VideoCNN  # noqa: E402

IMG_SIZE = 224
BATCH_SIZE = 32
EPOCHS = 15
LR = 1e-4  # lower LR since we're fine-tuning a pretrained backbone

transform = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])


class FaceDataset(Dataset):
    def __init__(self, root_dir: str, transform=None):
        self.transform = transform
        real = glob.glob(os.path.join(root_dir, "real", "*.jpg"))
        fake = glob.glob(os.path.join(root_dir, "fake", "*.jpg"))
        self.samples = [(p, 0) for p in real] + [(p, 1) for p in fake]

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]
        img = Image.open(path).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img, torch.tensor([label], dtype=torch.float32)


def train():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Training on {device}")

    train_ds = FaceDataset("data/faces/train", transform=transform)
    val_ds = FaceDataset("data/faces/val", transform=transform)

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=2)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, num_workers=2)

    model = VideoCNN(pretrained=True).to(device)

    # freeze backbone initially, only train the new classification head
    for name, param in model.backbone.named_parameters():
        if "fc" not in name:
            param.requires_grad = False

    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=LR)

    best_val_loss = float("inf")
    for epoch in range(EPOCHS):
        # unfreeze the whole backbone after a few warmup epochs
        if epoch == 3:
            for param in model.backbone.parameters():
                param.requires_grad = True
            optimizer = torch.optim.Adam(model.parameters(), lr=LR / 10)
            print("  -> unfroze full backbone, lowered LR")

        model.train()
        train_loss = 0.0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            out = model(x)
            loss = criterion(out, y)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        model.eval()
        val_loss = 0.0
        correct = 0
        total = 0
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(device), y.to(device)
                out = model(x)
                val_loss += criterion(out, y).item()
                preds = (torch.sigmoid(out) > 0.5).float()
                correct += (preds == y).sum().item()
                total += y.size(0)

        avg_train_loss = train_loss / len(train_loader)
        avg_val_loss = val_loss / len(val_loader)
        val_acc = correct / total

        print(f"Epoch {epoch+1}/{EPOCHS} | train_loss={avg_train_loss:.4f} "
              f"val_loss={avg_val_loss:.4f} val_acc={val_acc:.4f}")

        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            os.makedirs("../../backend/video_service/model_weights", exist_ok=True)
            torch.save(model.state_dict(), "../../backend/video_service/model_weights/video_cnn.pt")
            print("  -> saved new best model")


if __name__ == "__main__":
    train()
